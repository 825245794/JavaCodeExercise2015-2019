package ex6;

public class Calendar_Month {
	String [] Month;
	public Calendar_Month()
	{
		Month=new String[12];
		Month[0]="Jan:";
		Month[1]="Feb:";
		Month[2]="Mar:";
		Month[3]="Apr:";
		Month[4]="May:";
		Month[5]="June:";
		Month[6]="July:";
		Month[7]="Aug:";
		Month[8]="Sept:";
		Month[9]="Oct:";
		Month[10]="Nov:";
		Month[11]="Dec:";
		
	}
}
