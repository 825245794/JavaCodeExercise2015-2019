package ex6;

public class Calendar_Week {
	String [][] Week;
	public Calendar_Week()
	{
		Week=new String[7][7];
		Week[0][0]="Sun ";
		Week[0][1]="Mon ";
		Week[0][2]="Tues ";
		Week[0][3]="Wed ";
		Week[0][4]="Thur ";
		Week[0][5]="Fri ";
		Week[0][6]="Sat ";
		
		
	}
}
