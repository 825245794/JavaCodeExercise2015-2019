package ex2;

public class oushu {
public static void sx()
{
	int k;
	for(k=0;k<=50;k++)
	{		
		if(k%2==0)
		{
		System.out.println(k);
	}}	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

sx();
	}}