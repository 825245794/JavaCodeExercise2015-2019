

package ex2;

public class scor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k=76;
		if(k>=90)
		{
	System.out.println("��");
		}
		if(k>=80&k<90)
		{
	System.out.println("��");
		}
		if(k>=70&k<80)
		{
	System.out.println("��");
		}
		if(k>=60&k<70)
		{
	System.out.println("����");
		}
		if(k<60)
		{
	System.out.println("������");
		}
	}
}