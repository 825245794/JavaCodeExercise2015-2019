package ex3;

public class TestAddressBook {

	/**
	 * @param args
	 */   public static void main(String args[]){
			// TODO Auto-generated method stub
			AddressBook zhangsan_add=new AddressBook();
			zhangsan_add.setName("zhangsan");
			zhangsan_add.setAddress("zhuyuan");
			zhangsan_add.setTel(123456);
			zhangsan_add.getAllInfo();
		}

}
