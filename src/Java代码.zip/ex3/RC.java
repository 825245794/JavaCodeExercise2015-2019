package ex3;

public interface RC {
	public abstract double Area();
	public abstract double perimeter();
}
	
	
