package ex5;

public class Test_Vehicle {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vehicle audi=new Car();
audi.start();
audi.stop();
Vehicle yongjiu=new Bike();
yongjiu.start();
yongjiu.stop();
	}

}
