package ex5;

public class J_shape_Pointer {
double a;
double b;
public J_shape_Pointer(double a,double b) {
	this.a = a;
	this.b = b;
}

}
