package ex5;

public interface J_Shape {
	public abstract double Area();
	public abstract double perimeter();
	public abstract void print();
	}


