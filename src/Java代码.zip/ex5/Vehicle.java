package ex5;

public interface Vehicle {
	public abstract void start();
	public abstract void stop();
}
