package ex5;

public class J_Shape_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
J_Shape a=new J_shape_Circle();
a.print();
a=new J_shape_Square();
a.print();
a=new J_shape_Triangle();
a.print();
	}
}
