package ex5;

public class Car implements Vehicle{
public void start()
{
	System.out.println("Car start");
}
public void stop()
{
	System.out.println("Car stop");
}
}
