package ex1;
import java.util.Calendar;
public class Calendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Calendar c=new java.util.Calendar();
		System.out.println(c.);
	}

}
