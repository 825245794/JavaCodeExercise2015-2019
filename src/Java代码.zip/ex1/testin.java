package ex1;

public class testin {
interface CanCry
{
	public abstract void cry();
}
}
