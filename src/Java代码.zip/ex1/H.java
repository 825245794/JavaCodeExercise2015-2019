package ex1;

public class H {
	public  int x =100;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H a=new H();
		a.x++;
		H b=new H();
		b.x--;
		System.out.println(b.x);
	}

}
