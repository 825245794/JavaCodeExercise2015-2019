package ex1;

import ex1.testin.CanCry;

public class Cat implements CanCry{
public void cry()
{
	System.out.println("2");
}
}