package ex4;

public class J_Human {
private int age;
private String sex;
private String name;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public String getSex() {
	return sex;
}
public void setAge(int age) {
	this.age = age;
}
public void setSex(String sex) {
	this.sex = sex;

}
public void print(){}
}
