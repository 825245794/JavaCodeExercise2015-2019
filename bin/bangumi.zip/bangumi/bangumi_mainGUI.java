package bangumi;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.xml.sax.SAXException;

import com.meterware.httpunit.GetMethodWebRequest;
import com.meterware.httpunit.HttpUnitOptions;
import com.meterware.httpunit.WebClient;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebResponse;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar; 
public class bangumi_mainGUI extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel[] label;
	int index=0;
	static Point origin = new Point();
	String totalweek;
	String weekcontent[]=new String[7];
	String[][] animename=new String[7][30];
	String[][] animetime=new String[7][30];
	String[][] animeurl=new String[7][30];
	int x=0,y=0;
	JLabel jltext[]=new JLabel[30];
	JLabel jltime[]=new JLabel[30];
	Calendar g = Calendar.getInstance();
	int c = g.get(Calendar.DAY_OF_WEEK) - 1;
	static String url;
	static int ii=0;
	JPanel panel=new JPanel();
	PopupMenu popupMenu1 = new PopupMenu();
    MenuItem menuItem1 = new MenuItem();
    static int record=-1;
	
	public bangumi_mainGUI() throws MalformedURLException,IOException, SAXException{
		URL();

		setSize(280, 420);
		setLayout(null);
		this.setUndecorated(true);
		this.setOpacity(0.58f);
		this.setBackground(new Color(0,0,0,0));
		
		//add(panel);
		for(int i=0;i<30;i++){
			jltext[i]=new JLabel("null");
			jltime[i]=new JLabel("null");
			jltext[i].setFont(new java.awt.Font("微软雅黑",1,11));
			jltime[i].setFont(new java.awt.Font("微软雅黑",1,10));
		}
		addlabeltext();
		int index=0;
		for(int i=0;i<30;i++){
			if(jltext[i].getText().equals("null"))
				continue;
			jltext[i].setBounds(75, i*24, 195, 20);
			jltext[i].setBackground(Color.black);
			jltext[i].setForeground(Color.white);
			jltext[i].setOpaque(true);
			add(jltext[i]);
			
			jltime[i].setBounds(1, i*24, 70, 20);
			jltime[i].setBackground(Color.black);
			jltime[i].setForeground(Color.white);
			
				
			
			jltext[i].addMouseMotionListener(new MouseMotionAdapter() {
				// 拖动
				public void mouseDragged(MouseEvent e) { 														
		
					Point p = getLocation(); 
					
					setLocation(p.x + e.getX() - origin.x, p.y + e.getY()
							- origin.y);
				}
	 
	   });  
			
			if(index==0&&jltime[i].getText().indexOf("已更新")==-1){
				record=i;
				
					
								
				jltime[i].setBackground(Color.red);
				jltext[i].setBackground(Color.red);
				index++;
			}
		
			
			jltime[i].setOpaque(true);
			add(jltime[i]);
		}
		menuItem1.setLabel("Exit");
		popupMenu1.add(menuItem1);
		add(popupMenu1);
		
		setVisible(true);
		
		this.addMouseListener(new MouseAdapter() {
			
			public void mousePressed(MouseEvent e) { 
					   triggerEvent(e);   
		        	
				origin.x = e.getX(); 
				origin.y = e.getY();
				}
			   public void mouseReleased(MouseEvent event) {   
	                triggerEvent(event);  
	            }  
				private void triggerEvent(MouseEvent event) { 
					int mods=event.getModifiers();
					if((mods&InputEvent.BUTTON3_MASK)!=0){
			           if (event.isPopupTrigger())   
			               popupMenu1.show(event.getComponent(), event.getX(), event.getY());   
			       }  }					 
       });
			
      
       
		this.addMouseMotionListener(new MouseMotionAdapter() {
			// 拖动
			public void mouseDragged(MouseEvent e) { 														
	
				Point p = getLocation(); 
				
				setLocation(p.x + e.getX() - origin.x, p.y + e.getY()
						- origin.y);
			}
		
		
		 
   });  
		
		
		 menuItem1.addActionListener(new java.awt.event.ActionListener() { //菜单1的事件监听
	        	public void actionPerformed(ActionEvent e) {
	        		System.exit(0);
	        	}
	        	});
	}
	
	public void addlabeltext(){
		System.out.println(c);
		if(c==7){
			c=0;
		}
		
		for(int i=0;i<30;i++){
			if(animename[c][i]==null){
				continue;
			}
			jltext[i].setText(animename[c][i]);
			jltime[i].setText(animetime[c][i]);
			
			url=animeurl[c][i];
			ii=i;
			jltext[i].addMouseListener(new MouseAdapter(){
				int j=ii;
				
				@Override
				public void mouseClicked(MouseEvent arg0) {
					// TODO Auto-generated method stub
					 
				            
								try {
									Desktop.getDesktop().browse(URI.create(animeurl[c][j]));
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							
				        
				    
					
				
				}

				@Override
				public void mouseEntered(MouseEvent arg0) {
					// TODO Auto-generated method stub
					if(j!=record){
						jltext[j].setBackground(new Color(230,156,33));
						jltime[j].setBackground(new Color(230,156,33));
					}
					else{
						jltext[j].setBackground(Color.red);
						jltime[j].setBackground(Color.red);
					}
				
					
				}

				@Override
				public void mouseExited(MouseEvent arg0) {
					// TODO Auto-generated method stub
					if(j!=record){
					jltext[j].setBackground(Color.black);
					jltime[j].setBackground(Color.black);
					}
				else{
					jltext[j].setBackground(Color.red);
					jltime[j].setBackground(Color.red);
				}
				}
				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					   triggerEvent(e);   
			        	
						origin.x = e.getX(); 
						origin.y = e.getY();
						}
					   public void mouseReleased(MouseEvent event) {   
			                triggerEvent(event);  
			            }  
						private void triggerEvent(MouseEvent event) { 
							int mods=event.getModifiers();
							if((mods&InputEvent.BUTTON3_MASK)!=0){
					           if (event.isPopupTrigger())   
					               popupMenu1.show(event.getComponent(), event.getX(), event.getY());   
					       }  					 
				}

				
				
			}
		);
		}
		
	}

	public void URL() throws MalformedURLException,IOException, SAXException{
	
		
	      try{ 
	    	  HttpUnitOptions.setExceptionsThrownOnScriptError(false);
	    	  WebConversation wc=new WebConversation();//初始化httpunit
	          GetMethodWebRequest req =new GetMethodWebRequest("http://bangumi.bilibili.com/anime/timeline");
	          WebResponse rep =wc.getResponse(req);
	          //System.out.println(rep.getText());
	          totalweek=new String(rep.getText());
	          subweekcontent();
	         // wc.assertTrue(true);
//	          WebLink[] links=rep.getLinks();
//	          for(int i=0;i < links.length;i++)
//	          {
//	             System.out.println(links[i].getURLString());
//	          }
//	          
//	          WebResponse n_rep=links[4].click();
//	          
//	          System.out.println(n_rep.getText());
	      }catch(Exception e) {
	          e.printStackTrace();
	         // assertFalse(false);
	 
	}
	      }
	
	public void subweekcontent(){
		int begin,end;
		for(int i=0;i<7;i++){
			if(i==6){
				begin=totalweek.indexOf("week-icon week-day-"+i);
				weekcontent[i]=totalweek.substring(begin);
				end=weekcontent[i].indexOf("week-icon week-day-0");
				weekcontent[i]=weekcontent[i].substring(0,end);
				continue;
			}
		begin=totalweek.indexOf("week-icon week-day-"+i);
		weekcontent[i]=totalweek.substring(begin);
		end=weekcontent[i].indexOf("week-icon week-day-"+(i+1));
		weekcontent[i]=weekcontent[i].substring(0,end);
		}
		anime();
		//System.out.println(weekcontent[3]);
	}
	
	public void anime(){

		System.out.println(" ");
		String time;
		String url;
		String name;
		String jishu;
		y=0;
		int begin=0,end;
		try{
		for(;;)
		{
		
		begin=weekcontent[index].indexOf("更新");
		animetime[x][y]=weekcontent[index].substring(begin-7, begin+2);
		//System.out.println(time);
		
		begin=weekcontent[index].indexOf("alt=\"");
		end=weekcontent[index].indexOf("\" />");
		
//		begin=weekcontent[index].indexOf("<span>");
//		end=weekcontent[index].indexOf("</span>");

		animename[x][y]=weekcontent[index].substring(begin+5, end);
		//System.out.println(name);
		
		begin=weekcontent[index].indexOf("http://bangumi.bilibili.com/anime/");
		end=weekcontent[index].indexOf("\" data-type=\"anime\"");
		animeurl[x][y]=weekcontent[index].substring(begin, end);
		//System.out.println(url);
		
		
		begin=weekcontent[index].indexOf("<p class=\"update-info\">")+23;
		jishu=weekcontent[index].substring(begin);
		for(int o=0;o<10;o++){
		if(jishu.charAt(o)=='<'){
		end=o;
		break;
		}
		}
		
		jishu=jishu.substring(0, end);
		animename[x][y]+="  "+jishu;
		weekcontent[index]=weekcontent[index].substring(begin+300);
		//System.out.println(time+"  网址:"+" "+url+"  \t"+jishu+"       "+name);
		y++;
		
		}}catch(Exception e){
		
			if(index==6){
				output();
			}
			else{
			index++;
			x++;
			
			anime();
			}
				
			}
	}
	
	public void output(){
		for(int i=0;i<7;i++){
			if(i==0){
				System.out.println("周日");
			}
			else if(i==1){
				System.out.println("周一");
			}
			else if(i==2){
				System.out.println("周二");
			}
			else if(i==3){
				System.out.println("周三");
			}
			else if(i==4){
				System.out.println("周四");
			}
			else if(i==5){
				System.out.println("周五");
			}
			else if(i==6){
				System.out.println("周六");
			}
			for(int y=0;y<30;y++){
				if(animetime[i][y]!=null&&animeurl[i][y]!=null)
				System.out.println(animetime[i][y]+"  网址:"+" "+animeurl[i][y]+"  \t"+animename[i][y]);
			}
		}
	}
}
